<?php
define ('DB_HOST',    'instance42506.db.xeround.com');
define('DB_PORT',	'4102');
define ('DB_NAME',    'Registrations');
define ('DB_USER',    'alpogi');
define ('DB_PASS',    'alpogi');
 
// define ('FB_ID',      '592774837417751');
// define ('FB_SECRET',  '67d915f8c08fe506c321a3ef0b2c927b');
?>